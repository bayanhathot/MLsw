from flask import Blueprint, jsonify, current_app, request
from werkzeug.security import generate_password_hash, check_password_hash
import secrets

from .utils import error_response, increment_success, increment_fail

auth = Blueprint("auth", __name__)


def ensure_auth_storage():
    """
    Make sure the app has users and tokens dictionaries.

    current_app.users:
        username -> hashed_password

    current_app.tokens:
        token -> username
    """
    if not hasattr(current_app, "users"):
        current_app.users = {}

    if not hasattr(current_app, "tokens"):
        current_app.tokens = {}


def get_json_body():
    """
    Authentication endpoints MUST receive JSON.

    Valid:
        {"username": "testuser", "password": "securepassword123"}

    Invalid:
        missing JSON body
        malformed JSON
        JSON list instead of object
    """
    if not request.is_json:
        return None

    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return None

    return data


def validate_username_password(data):
    """
    The interface says username and password must be strings.
    """
    username = data.get("username")
    password = data.get("password")

    if not isinstance(username, str):
        return None, None

    if not isinstance(password, str):
        return None, None

    if username == "" or password == "":
        return None, None

    return username, password


def get_authenticated_user():
    """
    Protected endpoints MUST receive:

        Authorization: Bearer <token>

    Anything else is invalid.
    """
    ensure_auth_storage()

    auth_header = request.headers.get("Authorization")

    if not auth_header:
        return None, None

    parts = auth_header.split()

    if len(parts) != 2:
        return None, None

    scheme, token = parts

    if scheme != "Bearer":
        return None, None

    username = current_app.tokens.get(token)

    if username is None:
        return None, None

    return token, username


@auth.route("/register", methods=["POST"])
def register():
    ensure_auth_storage()

    data = get_json_body()

    if data is None:
        increment_fail()
        return error_response(400, "Malformed request")

    username, password = validate_username_password(data)

    if username is None or password is None:
        increment_fail()
        return error_response(400, "Malformed request")

    if username in current_app.users:
        increment_fail()
        return error_response(409, "Username already exists")

    current_app.users[username] = generate_password_hash(password)

    increment_success()
    return jsonify({
        "message": "User registered successfully"
    }), 201


@auth.route("/login", methods=["POST"])
def login():
    ensure_auth_storage()

    data = get_json_body()

    if data is None:
        increment_fail()
        return error_response(400, "Malformed request")

    username, password = validate_username_password(data)

    if username is None or password is None:
        increment_fail()
        return error_response(400, "Malformed request")

    stored_password_hash = current_app.users.get(username)

    if stored_password_hash is None:
        increment_fail()
        return error_response(401, "Invalid username or password")

    if not check_password_hash(stored_password_hash, password):
        increment_fail()
        return error_response(401, "Invalid username or password")

    token = secrets.token_hex(32)

    while token in current_app.tokens:
        token = secrets.token_hex(32)

    current_app.tokens[token] = username

    increment_success()
    return jsonify({
        "token": token
    }), 200


@auth.route("/logout", methods=["POST"])
def logout():
    ensure_auth_storage()

    token, username = get_authenticated_user()

    if token is None:
        increment_fail()
        return error_response(401, "Missing or invalid token")

    current_app.tokens.pop(token, None)

    increment_success()
    return jsonify({
        "message": "Logged out successfully"
    }), 200