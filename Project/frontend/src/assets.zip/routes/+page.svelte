<script>
  /*
    Home page route: /

    This is the main AI DJ page.

    Flow:
    - User writes/selects a vibe.
    - User starts the AI DJ session.
    - Player appears.
    - User gives feedback.
    - Optional AI reasoning can be opened.

    This page reads from sessionStore.
    It does not directly call the backend.
  */

  import { APP_STATES } from "$lib/constants/appStates.js";
  import { sessionStore } from "$lib/stores/sessionStore.js";

  import HeroSection from "$lib/components/HeroSection.svelte";
  import DJPlayerCard from "$lib/components/DJPlayerCard.svelte";
  import PromptComposer from "$lib/components/PromptComposer.svelte";
  import FeedbackButtons from "$lib/components/FeedbackButtons.svelte";
  import AIReasoningPanel from "$lib/components/AIReasoningPanel.svelte";
</script>

<HeroSection />

<DJPlayerCard
  status={$sessionStore.status}
  currentStep={$sessionStore.currentStep}
  progress={$sessionStore.progress}
  session={$sessionStore.session}
  isPlaying={$sessionStore.isPlaying}
  onTogglePlay={sessionStore.togglePlay}
  onStop={sessionStore.stop}
/>

<PromptComposer
  prompt={$sessionStore.prompt}
  isStarting={$sessionStore.status === APP_STATES.STARTING}
  onPromptChange={sessionStore.setPrompt}
  onStart={sessionStore.start}
/>

{#if $sessionStore.status === APP_STATES.PLAYING}
  <FeedbackButtons
    selectedFeedback={$sessionStore.selectedFeedback}
    onFeedback={sessionStore.sendFeedback}
  />

  <AIReasoningPanel
    session={$sessionStore.session}
    isOpen={$sessionStore.reasoningOpen}
    onToggle={sessionStore.toggleReasoning}
  />
{/if}

{#if $sessionStore.status === APP_STATES.ERROR}
  <section class="error-box card">
    <h3>Something went wrong</h3>
    <p>{$sessionStore.error}</p>
    <button class="secondary-button" onclick={sessionStore.reset}>
      Try again
    </button>
  </section>
{/if}

<style>
  .error-box {
    padding: 24px;
    margin-bottom: 24px;
  }

  .error-box p {
    color: var(--text-muted);
  }
</style>