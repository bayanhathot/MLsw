<script>
  /**
   * Purpose:
   * Top navigation for the Smart AI DJ homepage.
   *
   * How this connects to the project:
   * It gives the app a real product identity while keeping the MVP no-login.
   * The sign-in button is intentionally visual for now; login is postponed until
   * save/history/personalization features exist.
   *
   * Engineering decision:
   * Navbar has no state. It is a simple presentational component.
   */
</script>
<nav class="navbar">
  <a class="logo" href="/">
    <span class="logo-mark">DJ</span>
    <span>Smart AI DJ Mixer</span>
  </a>

  <div class="links">
    <a class="secondary-button" href="/login">Sign in</a>
  </div>
</nav>

<style>
  .navbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 22px 0;
  }

  .logo {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    color: var(--text-main);
    text-decoration: none;
    font-weight: 800;
  }

  .logo-mark {
    display: inline-grid;
    place-items: center;
    width: 42px;
    height: 42px;
    border-radius: 14px;
    background: linear-gradient(135deg, var(--accent), var(--accent-2));
    color: white;
    font-size: 14px;
    letter-spacing: 0.05em;
  }

  .links {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  @media (max-width: 640px) {
    .links {
      display: none;
    }
  }
</style>